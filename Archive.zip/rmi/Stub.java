package rmi;

import java.io.*;

import java.net.*;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

/** RMI stub factory.

    <p>
    RMI stubs hide network communication with the remote server and provide a
    simple object-like interface to their users. This class provides methods for
    creating stub objects dynamically, when given pre-defined interfaces.

    <p>
    The network address of the remote server is set when a stub is created, and
    may not be modified afterwards. Two stubs are equal if they implement the
    same interface and carry the same remote server address - and would
    therefore connect to the same skeleton. Stubs are serializable.
 */
public abstract class Stub
{
    /** Creates a stub, given a skeleton with an assigned adress.

        <p>
        The stub is assigned the address of the skeleton. The skeleton must
        either have been created with a fixed address, or else it must have
        already been started.

        <p>
        This method should be used when the stub is created together with the
        skeleton. The stub may then be transmitted over the network to enable
        communication with the skeleton.

        @param c A <code>Class</code> object representing the interface
                 implemented by the remote object.
        @param skeleton The skeleton whose network address is to be used.
        @return The stub created.
        @throws IllegalStateException If the skeleton has not been assigned an
                                      address by the user and has not yet been
                                      started.
        @throws UnknownHostException When the skeleton address is a wildcard and
                                     a port is assigned, but no address can be
                                     found for the local host.
        @throws NullPointerException If any argument is <code>null</code>.
        @throws Error If <code>c</code> does not represent a remote interface
                      - an interface in which each method is marked as throwing
                      <code>RMIException</code>, or if an object implementing
                      this interface cannot be dynamically created.
     */
    public static <T> T create(Class<T> c, Skeleton<T> skeleton)
        throws UnknownHostException
    {
        if (c == null || skeleton == null)
            throw new NullPointerException();

        if (skeleton.address == null || !skeleton.started)
            throw new IllegalStateException();

        // * check if the interface is remote
        if (!checkError.check_Error_Exception(c.getMethods()))
            throw new Error();
        
        // * create the stub as a proxy
        Object stub = Proxy.newProxyInstance(c.getClassLoader(),
                                             new Class[] {c},
                                             new StubInvocationHandler<T>(c, skeleton.address));
        return (T)stub;
    }

    /** Creates a stub, given a skeleton with an assigned address and a hostname
        which overrides the skeleton's hostname.

        <p>
        The stub is assigned the port of the skeleton and the given hostname.
        The skeleton must either have been started with a fixed port, or else
        it must have been started to receive a system-assigned port, for this
        method to succeed.

        <p>
        This method should be used when the stub is created together with the
        skeleton, but firewalls or private networks prevent the system from
        automatically assigning a valid externally-routable address to the
        skeleton. In this case, the creator of the stub has the option of
        obtaining an externally-routable address by other means, and specifying
        this hostname to this method.

        @param c A <code>Class</code> object representing the interface
                 implemented by the remote object.
        @param skeleton The skeleton whose port is to be used.
        @param hostname The hostname with which the stub will be created.
        @return The stub created.
        @throws IllegalStateException If the skeleton has not been assigned a
                                      port.
        @throws NullPointerException If any argument is <code>null</code>.
        @throws Error If <code>c</code> does not represent a remote interface
                      - an interface in which each method is marked as throwing
                      <code>RMIException</code>, or if an object implementing
                      this interface cannot be dynamically created.
     */
    public static <T> T create(Class<T> c, Skeleton<T> skeleton,
                               String hostname)
    {
        if (c == null || skeleton == null || hostname == null)
            throw new NullPointerException();

        if (skeleton.port == 0)
            throw new IllegalStateException();

        // * check if the interface is remote
        if (!checkError.check_Error_Exception(c.getMethods()))
            throw new Error();

        InetSocketAddress address = new InetSocketAddress(hostname, skeleton.port);

        // * create the stub as a proxy
        Object stub = Proxy.newProxyInstance(c.getClassLoader(),
                                           new Class[] {c},
                                           new StubInvocationHandler<T>(c, address));
        return (T)stub;
    }

    /** Creates a stub, given the address of a remote server.

        <p>
        This method should be used primarily when bootstrapping RMI. In this
        case, the server is already running on a remote host but there is
        not necessarily a direct way to obtain an associated stub.

        @param c A <code>Class</code> object representing the interface
                 implemented by the remote object.
        @param address The network address of the remote skeleton.
        @return The stub created.
        @throws NullPointerException If any argument is <code>null</code>.
        @throws Error If <code>c</code> does not represent a remote interface
                      - an interface in which each method is marked as throwing
                      <code>RMIException</code>, or if an object implementing
                      this interface cannot be dynamically created.
     */
    public static <T> T create(Class<T> c, InetSocketAddress address)
    {
        if (c == null || address == null)
        {
            throw new NullPointerException();
        }

        // * check if the interface is remote
        if (!checkError.check_Error_Exception(c.getMethods()))
            throw new Error();
        
        // * create the stub as a proxy
        Object stub = Proxy.newProxyInstance(c.getClassLoader(),
                                           new Class[] {c},
                                           new StubInvocationHandler<T>(c, address));
        return (T)stub;
    }
}

/**
    * A class implementing the invoke method so all method calls are
    * directed to it
    */
class StubInvocationHandler<T> implements InvocationHandler, Serializable {
    Class<T> c;
    InetSocketAddress address;

    // * constructer to save the address and the interface
    public StubInvocationHandler(Class<T> c, InetSocketAddress address)
    {
        this.address = address;
        this.c = c;
    }

    /**
     * This method is called whenever the proxy is called on any method to handle it
     */
    @Override
    public Object invoke(Object stub, Method method, Object[] args) throws Throwable {
        Object result;
        // socket & streams
        Socket socket = null;
        ObjectOutputStream out = null;
        ObjectInputStream in = null;

        // * handle if a local method
        result = invokeIfLocal(method.getName(), args);
        if (result != null) return result;

        try
        {
            // * create the socket and the streams
            socket = new Socket();
            socket.connect(this.address);
            out = new ObjectOutputStream(socket.getOutputStream());
            in = new ObjectInputStream(socket.getInputStream());
            
            // * marshall the method name, param, param types 
            out.writeObject(method.getName());
            out.writeObject(method.getParameterTypes());
            out.writeObject(args);
            out.flush();

            // * read the result back from the skeleton
            result = in.readObject();

        } catch (Exception e) {
            throw new RMIException("Failed to communicate with the skeleton");
        } finally {
            checkError.close_all(socket, out, in);

            // * if calling the function retuerned an exception, throw it
            if (result instanceof Exception)
                throw (Throwable) result;
        }

        return result;			
    }

    /**
     * Local function to compare two proxies "invocation handlers"
     */
    @Override
    public boolean equals(Object proxy)
    {
        // * check if the given object is actually a proxy
        if (proxy == null || !(proxy instanceof Proxy))
            return false;
        
        // * get the invocationHandler for the proxy
        StubInvocationHandler<T> handler = (StubInvocationHandler<T>) 
                                            Proxy.getInvocationHandler(proxy);

        /**
         * * two proxies are equal if they have the same interface
         * * and connected to the same skeleton
         */
        if (this.address.equals(handler.address)
         && this.c.equals(handler.c))
            return true;

        else
            return false;
    }

    /**
     * Local fuction to calculate the hash for the proxy
     */
    @Override
    public int hashCode()
    {
        if (c == null && address == null)
            return 0;
        else if (c == null && address != null)
            return address.hashCode();
        else if (c != null && address == null)
            return c.hashCode();
        
        // * hashing is consistent with equal
        else
            return c.hashCode() + address.hashCode();
    }

    /**
     * 
     * @param name method name
     * @param args method args
     * @return Object -> if name represents a local method || null -> otherwise
     */
    public Object invokeIfLocal(String name, Object[] args)
    {
        // * if the function is local, call the respective function
        switch(name)
        {
            case "equals":
                return this.equals(args[0]);
            case "hashCode":
                return this.hashCode();
            case "toString":
                // * use the default function for toString
                return this.toString();
            default:
                return null;
        }
    }
}


/**
 * 
 * A class implementing one function that checks if an interface is remot
 */
class checkError
{
    /**
     * 
     * @param methods a list of methods that an interface is implementing
     * @return true -> if all methods throw RMIException || false -> otherwise
     */
    public static boolean check_Error_Exception(Method[] methods)
    {
        boolean foundRMI;

        for (int i = 0; i < methods.length; i++)
        {
            foundRMI = false;

            // * get all the exceptions for this method
            Class<?> Es[] = methods[i].getExceptionTypes();
            for (int j = 0; j < Es.length; j++)
            {
                // * check if RMIException is one of the exceptions
                if (Es[j] == RMIException.class)
                    foundRMI = true;
            }

            if (!foundRMI)
                return false;
        }

        return true;
    }

    /**
     * 
     * @param socket socket to close
     * @param out output strem to close
     * @param in input stream to close
     * @throws RMIException If it can't clsoe
     */
    public static void close_all(Socket socket, 
                          ObjectOutputStream out, 
                          ObjectInputStream in)
                          throws RMIException
    {
        try {
            if (socket != null) socket.close();
            if (out != null) out.close();
            if (in != null) in.close();   
        } catch (Exception e) {
            throw new RMIException("Failed to close communication");
        }
    }
}