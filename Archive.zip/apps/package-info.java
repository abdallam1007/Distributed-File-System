/** Filesystem applications.

    <p>
    Filesystem applications provide ways to start naming and storage servers
    from the command line, and several client commands such as <code>put</code>,
    <code>get</code>, <code>mkdir</code>, and <code>ls</code>.
 */
package apps;
