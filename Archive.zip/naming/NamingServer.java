package naming;

import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.Semaphore;

import rmi.*;
import common.*;
import storage.*;

/** Naming server.

    <p>
    Each instance of the filesystem is centered on a single naming server. The
    naming server maintains the filesystem directory tree. It does not store any
    file data - this is done by separate storage servers. The primary purpose of
    the naming server is to map each file name (path) to the storage server
    which hosts the file's contents.

    <p>
    The naming server provides two interfaces, <code>Service</code> and
    <code>Registration</code>, which are accessible through RMI. Storage servers
    use the <code>Registration</code> interface to inform the naming server of
    their existence. Clients use the <code>Service</code> interface to perform
    most filesystem operations. The documentation accompanying these interfaces
    provides details on the methods supported.

    <p>
    Stubs for accessing the naming server must typically be created by directly
    specifying the remote network address. To make this possible, the client and
    registration interfaces are available at well-known ports defined in
    <code>NamingStubs</code>.
 */
public class NamingServer implements Service, Registration
{
    public static Node root;
    public static ArrayDeque<StorageLeaf> storages;
    Skeleton<Service> service_skltn; 
    Skeleton<Registration> reg_skltn;

    public static double ALPHA;
    public static double REPLICA_UPPER_BOUND;

    public class Node
    {
        String name;

        int readers;
        Semaphore serviceQueue;
        Semaphore rmutex;
        Semaphore resource;

        public Node(String name)
        {
            this.name = name;

            this.readers = 0;
            this.serviceQueue = new Semaphore(1);
            this.rmutex = new Semaphore(1);
            this.resource = new Semaphore(1);
        }
    }
    
    public class Branch extends Node
    {
        ArrayList<Node> list;

        /**
         * 
         * @param node_name
         * @return a branch without any children (NOT a null array)
         */
        public Branch(String name)
        {
            super(name);
            this.list = new ArrayList<Node>();
        }
    }

    public class Leaf extends Node
    {
        int numOfReads;
        int numOfReplicas;
        ArrayDeque<StorageLeaf> SSs;
        Path path;

        public Leaf(String name, Path path, Command c, Storage s)
        {
            super(name);

            this.numOfReads = 0;
            this.numOfReplicas = 0;
            this.SSs = new ArrayDeque<StorageLeaf>();
            this.SSs.add(new StorageLeaf(c, s));
            this.path = path;
        }
    }

    public class StorageLeaf
    {
        Command c;
        Storage s;

        public StorageLeaf(Command c, Storage s)
        {
            this.c = c;
            this.s = s;
        }
    }


    /** Creates the naming server object.

        <p>
        The naming server is not started.
     */
    public NamingServer()
    {
        // * Root is represented as a branch with no children and an empty name
        // * create the directory tree
        NamingServer.root = new Branch("");
        // * create the storage list, saving the registered storages
        NamingServer.storages = new ArrayDeque<StorageLeaf>();

        NamingServer.ALPHA = 0.1;
        NamingServer.REPLICA_UPPER_BOUND = 20;
    }

    /** Starts the naming server.

        <p>
        After this method is called, it is possible to access the client and
        registration interfaces of the naming server remotely.

        @throws RMIException If either of the two skeletons, for the client or
                             registration server interfaces, could not be
                             started. The user should not attempt to start the
                             server again if an exception occurs.
     */
    public synchronized void start() throws RMIException
    {
        try {

            // * create the Service Skeleton and start it
            InetSocketAddress service_address = new InetSocketAddress(NamingStubs.SERVICE_PORT);
            this.service_skltn = new Skeleton<Service>(Service.class,
                                                            new NamingServer(),
                                                            service_address);
            this.service_skltn.start();

            // * create the Registeration Skeleton and start it
            InetSocketAddress reg_address = new InetSocketAddress(NamingStubs.REGISTRATION_PORT);
            this.reg_skltn = new Skeleton<Registration>(Registration.class, 
                                                            new NamingServer(), 
                                                            reg_address);
            this.reg_skltn.start();
        
        } catch (Exception e) {
            throw new RMIException("Error creating Service and Rigesteration Skeletons ");
        }

        return;
    }

    /** Stops the naming server.

        <p>
        This method waits for both the client and registration interface
        skeletons to stop. It attempts to interrupt as many of the threads that
        are executing naming server code as possible. After this method is
        called, the naming server is no longer accessible remotely. The naming
        server should not be restarted.
     */
    public void stop()
    {
        // * stop the skeletons
        service_skltn.stop();
        reg_skltn.stop();
        this.stopped(null);
        return;
    }

    /** Indicates that the server has completely shut down.

        <p>
        This method should be overridden for error reporting and application
        exit purposes. The default implementation does nothing.

        @param cause The cause for the shutdown, or <code>null</code> if the
                     shutdown was by explicit user request.
     */
    protected void stopped(Throwable cause)
    {
    }

    public void lock(Path path, boolean exclusive)
        throws RMIException, FileNotFoundException
    {
        int index;
        String comp = "";
        Node curr = NamingServer.root;
        Branch curr_branch = (Branch)curr;
        Iterator<String> it = path.iterator();

        // * Traverse the path
        while (it.hasNext())
        {
            if (!path.last().equals(comp))
            {
                // * Path not finished but tree reached a Leaf
                if (!(curr instanceof Branch))
                    throw new FileNotFoundException();

                // * lock the directory for reading
                nodeReadLock(curr);
            }

            // * check if directory/file exists
            comp = it.next();
            curr_branch = (Branch)curr;
            index = is_comp_exists(curr_branch.list, comp);
            if (index == -1)
                throw new FileNotFoundException();
        
            curr = curr_branch.list.get(index);
        }
        
        // * lock the file for reading or writing
        nodeLock(path, curr, exclusive);
    }

    public void unlock(Path path, boolean exclusive) throws RMIException
    {
        int index;
        String comp = "";
        Node curr = NamingServer.root;
        Branch curr_branch = (Branch)curr;
        Iterator<String> it = path.iterator();

        // * Traverse the path
        while (it.hasNext())
        {
            if (!path.last().equals(comp))
            {
                // * Path not finished but tree reached a Leaf
                if (!(curr instanceof Branch))
                    throw new IllegalArgumentException();

                // * lock the directory for reading
                nodeReadUnlock(curr);
            }

            // * check if directory/file exists
            comp = it.next();
            curr_branch = (Branch)curr;
            index = is_comp_exists(curr_branch.list, comp);
            if (index == -1)
                throw new IllegalArgumentException();
        
            curr = curr_branch.list.get(index);
        }

        // * lock the file for reading or writing
        if (exclusive)
            nodeWriteUnlock(curr);

        else
            nodeReadUnlock(curr);
    }

    // The following methods are documented in Service.java.
    @Override
    public boolean isDirectory(Path path) throws FileNotFoundException
    {
        // * check if the path exists in the tree
        Node curr_node = getNode(path);
        if (curr_node == null)
            throw new FileNotFoundException();
        
        else
            return (curr_node instanceof Branch); // * check that it is indeed a directory
    }

    @Override
    public String[] list(Path directory) throws FileNotFoundException 
    {
        Node curr_node;
        Branch curr_branch;

        // * check if the directory exists
        curr_node = getNode(directory);
        if (curr_node == null)
            throw new FileNotFoundException();

        // * check if the path referes to a directory
        if (!isDirectory(directory))
            throw new FileNotFoundException();

        // * list all the files/directories under the directory
        curr_branch = (Branch)curr_node;
        String[] childs = new String[curr_branch.list.size()];
        for (int j = 0; j < curr_branch.list.size(); j++)
            childs[j] = curr_branch.list.get(j).name;

        return childs;
    }

    @Override
    public boolean createFile(Path file)
        throws RMIException, FileNotFoundException
    {
        int index;
        Node curr_node;
        Branch curr_branch;

        // * reject null paths
        if (file == null)
            throw new NullPointerException();

        // * can't create the root
        if (file.isRoot())
            return false;

        // * check no storages have registered
        if (NamingServer.storages.size() == 0)
            throw new IllegalStateException();

        // * check if parent's directory exists
        curr_node = getNode(file.parent());
        if (curr_node == null)
            throw new FileNotFoundException();

        // * check if the curr node referes to the parent directory
        if (!isDirectory(file.parent()))
            throw new FileNotFoundException();

        // * check if file already exists
        curr_branch = (Branch)curr_node;
        index = is_comp_exists(curr_branch.list, file.last());

        // * directory/file already exists with the same name
        if (index != -1)
            return false;
    
        else // * create the file at this branch
            return send_create_call(file, curr_branch.list);
    }

    @Override
    public boolean createDirectory(Path directory) throws FileNotFoundException
    {
        int index;
        Node curr_node;
        Branch curr_branch;

        // * reject null paths
        if (directory == null)
            throw new NullPointerException();

        // * can't create the root
        if (directory.isRoot())
            return false;

        // * check if parent's directory exists
        curr_node = getNode(directory.parent());
        if (curr_node == null)
            throw new FileNotFoundException();

        // * check if the curr node referes to the parent directory
        if (!isDirectory(directory.parent()))
            throw new FileNotFoundException();
        
        // * check if file already exists
        curr_branch = (Branch)curr_node;
        index = is_comp_exists(curr_branch.list, directory.last());

        if (index != -1)
            return false; // * a file or a directory with the same path already exists
    
        else // * create the directory at this branch
        {
            Branch branch = new Branch(directory.last());
            curr_branch.list.add(branch);
            return true;
        }
    }

    @Override
    public boolean delete(Path path) throws RMIException, FileNotFoundException
    {
        Node parent_node;
        Branch curr_branch;

        // * reject null paths
        if (path == null)
            throw new NullPointerException();

        // * can't delete the root
        if (path.isRoot())
            return false;

        // * check if parent directory exists in the tree
        parent_node = getNode(path.parent());
        if (parent_node == null)
            throw new FileNotFoundException();

        // * check if the curr node referes to the parent directory
        if (!isDirectory(path.parent()))
            throw new FileNotFoundException();

        // * delete the node that has the file
        curr_branch = (Branch)parent_node;
        return delete_node(curr_branch, path);
    }

    @Override
    public Storage getStorage(Path file) throws FileNotFoundException
    {
        Node curr_node;
        StorageLeaf storage;

        // * check if file exists in the tree
        curr_node = getNode(file);
        if (curr_node == null)
            throw new FileNotFoundException();
        
        // * check if the path referes to a file
        if (isDirectory(file))
            throw new FileNotFoundException();
        
        // * return the storage stub in a round-robin way
        storage = ((Leaf)curr_node).SSs.remove();
        ((Leaf)curr_node).SSs.add(storage);
        return storage.s;
    }

    // The method register is documented in Registration.java.
    @Override
    public Path[] register(Storage client_stub, Command command_stub,
                           Path[] files)
    {
        Path[] dups;
        StorageLeaf storage;
        boolean storage_exists;

        if (client_stub == null || command_stub == null || files == null)
            throw new NullPointerException();

        // * Craete storage representation
        storage = new StorageLeaf(command_stub, client_stub);
        // * check if storage already exists. If not, add it
        storage_exists = is_storage_registered(NamingServer.storages, storage);
        if (storage_exists)
            throw new IllegalStateException();
        else
            NamingServer.storages.add(storage);

        // * register th files and get back the list of dup files
        dups = register_to_tree(files, command_stub, client_stub);
        return dups;
    }


    /**
     * 
     * @description Traverse the given path along with the directory tree 
     *              and return the node representing the last component
     * 
     * @param path
     * @return node --> representing the file/directory of the last component
     */
    public Node getNode(Path path)
    {
        int index;
        String comp = "";
        Node curr = NamingServer.root;
        Branch curr_branch = (Branch)curr;
        Iterator<String> it = path.iterator();

        // * Traverse the path
        while (it.hasNext())
        {
            // * Path not finished but tree reached a Leaf
            if (!(curr instanceof Branch))
                return null;

            comp = it.next();
            curr_branch = (Branch)curr;

            // * check if directory exists
            index = is_comp_exists(curr_branch.list, comp);
            if (index == -1)
                return null;
        
            curr = curr_branch.list.get(index);
        }

        return curr;
    }

    /**
     * 
     * @description This function checks if there is any node in the given
     *              list of nodes that has the same name as comp
     * 
     * @param list a list of Nodes
     * @param comp the string to find
     * @return index --> if found || -1 --> otherwise
     */
    public int is_comp_exists(ArrayList<Node> list, String comp)
    {
        int i;

        // * looping through the nodes and comparing the name to comp
        for (i = 0; i < list.size(); i++)
        {
            if (comp.equals(list.get(i).name))
                return i;
        }

        return -1;
    }

    /**
     * 
     * @description given a list of storages, figure out if a new storage
     *              was already registered or not
     * 
     * @param storage_list a list of registered storages
     * @param new_storage storage to be added
     * @return true --> already registered || false --> otherwise
     */
    public boolean is_storage_registered(ArrayDeque<StorageLeaf> storageQ, StorageLeaf new_storage)
    {
        boolean isFound = false;
        ArrayDeque<StorageLeaf> tempQ = new ArrayDeque<StorageLeaf>();

        /**
         * * looping through the storages to find a storage 
         * * with the same command and storage stubs
         */

        while (!storageQ.isEmpty())
        {
            StorageLeaf storage = storageQ.remove();
            tempQ.add(storage);

            if (storage.c.equals(new_storage.c)
            && storage.s.equals(new_storage.s))
               isFound = true;
        }

        while (!tempQ.isEmpty())
            storageQ.add(tempQ.remove());

        return isFound;
    }

    /**
     * 
     * @param files files to be registered at the directory tree
     * @param command_stub the command stub for the new storage server
     * @param storage_stub the storage stub for the new storage server
     * @return list of duplciate files to be deleted
     */
    public Path[] register_to_tree(Path[] files, Command command_stub, Storage storage_stub)
    {
        Path[] dups;
        boolean is_not_dup;
        ArrayList<Path> dups_array;

        /**
         * * loop through the files. Create it if it doesn't exist
         * * If it does exist, then add it to the dups array
         */ 
        dups_array = new ArrayList<Path>();
        for (int i = 0; i < files.length; i++)
        {
            if (!files[i].isRoot())
            {
                is_not_dup = register_file(files[i], command_stub, storage_stub);
                if (!is_not_dup)
                    dups_array.add(files[i]);
            }
        }
        
        dups = new Path[dups_array.size()];
        dups = dups_array.toArray(dups);
        return dups;
    }

    /**
     * 
     * @param files files to be registered at the directory tree
     * @param command_stub the command stub for the new storage server
     * @param client_stub the storage stub for the new storage server
     * @return true --> file created || false --> file already existed
     */
    public boolean register_file(Path file, Command command_stub, Storage client_stub)
    {
        int index;
        String comp = file.last();
        Node parent = NamingServer.root;
        Leaf new_leaf;
        Branch parent_branch = (Branch)NamingServer.root;
        Iterator<String> it = file.iterator();

        // * loop through the path and create all the parent directories recursively
        while(it.hasNext())
        {
            comp = it.next();
            if (comp != file.last()) // * last component is the filename
                parent = register_parent_dir(parent, comp);
        }

        // * check if the file already exists under this branch
        parent_branch = (Branch)parent;
        index = is_comp_exists(parent_branch.list, comp);
        if (index != -1)
            return false;


        // * if file didn't exist, create it as a Leaf
        new_leaf = new Leaf(comp, file, command_stub, client_stub);
        parent_branch.list.add(new_leaf);
        return true;
    }


    /**
     * 
     * @param parent The parent branch of this directory name
     * @param dir_name The directory name to add
     * @return a branch representing the dir_name
     */
    public Node register_parent_dir(Node parent, String dir_name)
    {
        int index;
        Node branch;
        Branch curr_branch;

        // * check if branch already exists
        curr_branch = (Branch)parent;
        index = is_comp_exists(curr_branch.list, dir_name);
        if (index != -1)
            return curr_branch.list.get(index);

        // * create a branch since it didn't exist
        branch = new Branch(dir_name);
        curr_branch.list.add(branch);
        return branch;
    }

    /**
     * 
     * @param file The path of the file to be created
     * @param parent_branch the parent's branch to create the file in
     * @return true --> file created || false --> file not created
     * @throws RMIException if a network error happens while creating
     */
    public boolean send_create_call(Path file, ArrayList<Node> parent_branch) throws RMIException
    {
        StorageLeaf storage = NamingServer.storages.remove();
        // * create a leaf in the tree to command the storage server
        Leaf leaf = new Leaf(file.last(),
                             file,
                             storage.c, 
                             storage.s);
        parent_branch.add(leaf);
        NamingServer.storages.add(storage);

        try {
            // * command the storage server to create the file
            storage.c.create(file);
            return true;
        } catch (RMIException e) {
            throw new RMIException("Error Creating a file on the storage server");
        }
    }

    /**
     * 
     * @param parent_branch branch holding the node to be deleted
     * @param comp component to delete
     * @return true -> deleted || false -> failed to delete
     * @throws RMIException
     */
    public boolean delete_node(Branch parent_branch, Path file) throws RMIException, FileNotFoundException
    {
        int i;
        Node node;
        Leaf leaf;

        StorageLeaf SS;
        ArrayDeque<StorageLeaf> tempQ = new ArrayDeque<StorageLeaf>();

        i = is_comp_exists(parent_branch.list, file.last());
        if (i == -1) // * deleting smth that didn't exist !!!
            throw new FileNotFoundException();

        else // * delete the directory/file at this branch recursively
        {
            try {
                node = parent_branch.list.get(i);

                // * check if leaf to send delete to storage server
                if (node instanceof Leaf)
                {
                    leaf = (Leaf)node;
                    while (!leaf.SSs.isEmpty())
                        leaf.SSs.remove().c.delete(leaf.path);
                }

                else
                {
                    // * delete directory from all storage servers
                    while (!NamingServer.storages.isEmpty())
                    {
                        SS = NamingServer.storages.remove();
                        SS.c.delete(file);
                        tempQ.add(SS);
                    }

                    while (!tempQ.isEmpty())
                        NamingServer.storages.add(tempQ.remove());
                }
    
                // * remove the directory/file from the naming server's tree
                parent_branch.list.remove(i);
                return true;
            } catch (Exception e) {
                throw new RMIException("Couldn't delete directory/file");
            }
        }
    }

    // * lock the file represented by path at node
    public void nodeLock(Path path, Node node, boolean exclusive)
    throws RMIException, FileNotFoundException
    {
        if (exclusive)
        {
            nodeWriteLock(node);

            // * invalidate all other files
            if (node instanceof Leaf)
                deleteFileFromSSs(path, (Leaf)node);
        }

        else
        {
            nodeReadLock(node);
            
            if (node instanceof Leaf)
            {
                // * update reads, update replicas
                ((Leaf)node).numOfReads++;
                updateReplicas((Leaf)node);
            }
        }
    }
    
    public void nodeReadLock(Node node) throws RMIException
    {
        try {
            node.serviceQueue.acquire();   // * wait in line to be serviced
            node.rmutex.acquire();         // * request exclusive access to readcount
            node.readers++;                // * update count of active readers
            if (node.readers == 1)         // * if I am the first reader
                node.resource.acquire();   // * request resource access for readers (writers blocked)
            node.serviceQueue.release();   // * let next in line be serviced
            node.rmutex.release();         // * release access to readcount
        } catch (Exception e) {
            throw new RMIException("failed to aquire a reader's lock for a node");
        }
    }

    public void nodeWriteLock(Node node) throws RMIException
    {
        try {
            node.serviceQueue.acquire();   // * wait in line to be serviced
            node.resource.acquire();       // * request exclusive access to resource
            node.serviceQueue.release();   // * let next in line be serviced   
        } catch (Exception e) {
            throw new RMIException("failed to aquire a writer's lock for a node");
        }
    }

    public void nodeReadUnlock(Node node) throws RMIException
    {
        try {
            node.rmutex.acquire();         // * request exclusive access to readcount
            node.readers--;                // * update count of active readers
            if (node.readers == 0)         // * if there are no readers left
                node.resource.release();   // * release resource access for all
            node.rmutex.release();         // * release access to readcount
        } catch (Exception e) {
            throw new RMIException("failed to aquire a reader's lock for a node");
        }
    }

    public void nodeWriteUnlock(Node node) throws RMIException
    {
        try {
            node.resource.release();   // * release resource access for next reader/writer 
        } catch (Exception e) {
            throw new RMIException("failed to aquire a writer's lock for a node");
        }
    }

    public void updateReplicas(Leaf leaf) throws RMIException
    {
        int curr_numOfReplicas = leaf.numOfReplicas;
        double num_requesters_coarse;

        if (leaf.numOfReads % 20 == 0)
        {
            // * num_requesters_coarse = {N | N >= num_requesters & a multiple of 20}
            num_requesters_coarse = leaf.numOfReads;

            // * num_replicas = min (ALPHA * num_requesters_coarse , REPLICA_UPPER_BOUND)
            leaf.numOfReplicas = (int)Math.min(NamingServer.ALPHA * num_requesters_coarse,
                                            NamingServer.REPLICA_UPPER_BOUND);
            
            // * a change occured -> update the SSs
            if (curr_numOfReplicas < leaf.numOfReplicas)
                updateSSs(leaf, leaf.numOfReplicas - curr_numOfReplicas - leaf.SSs.size());
        }
    }

    public void updateSSs(Leaf leaf, int newSSs) throws RMIException
    {
        try {
            // * has the updated copy
            Storage initS = leaf.SSs.peek().s;
            while (newSSs > 0)
            {
                // * if the storage server isn't already in the list, add it
                StorageLeaf storage = NamingServer.storages.remove();
                if (!storage_exists(leaf.SSs, storage.s))
                {
                    leaf.SSs.add(storage);
                    // * relicate the file
                    storage.c.copy(leaf.path, initS);
                    newSSs--;
                }
    
                NamingServer.storages.add(storage);
            }   
        } catch (Exception e) {
            throw new RMIException("Couldn't ask storage server to copy a file");
        }
    }

    public boolean storage_exists(ArrayDeque<StorageLeaf> SSs, Storage S)
    {
        boolean isFound = false;
        ArrayDeque<StorageLeaf> tempQ = new ArrayDeque<StorageLeaf>();

        /**
         * * looping through the storages to find a storage 
         * * with the same command and storage stubs
         */

        while (!SSs.isEmpty())
        {
            StorageLeaf storage = SSs.remove();
            tempQ.add(storage);

            if (storage.s.equals(S))
               isFound = true;
        }

        while (!tempQ.isEmpty())
            SSs.add(tempQ.remove());

        return isFound;
    }

    public void deleteFileFromSSs(Path file, Leaf fileLeaf) throws RMIException
    {
        ArrayDeque<StorageLeaf> tempQ = new ArrayDeque<StorageLeaf>();

        /**
         * * looping through the storages to delete the file 
         * * from the other storages
         */

        Storage initS = fileLeaf.SSs.peek().s;

        while (!fileLeaf.SSs.isEmpty())
        {
            StorageLeaf storage = fileLeaf.SSs.remove();
            tempQ.add(storage);

            if (!storage.s.equals(initS))
            {
                storage.c.delete(file);
            }
        }

        while (!tempQ.isEmpty())
            fileLeaf.SSs.add(tempQ.remove());
    }
}