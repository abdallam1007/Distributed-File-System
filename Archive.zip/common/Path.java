package common;

import java.util.*;
import java.io.*;
import java.net.*;

/** Distributed filesystem paths.

    <p>
    Objects of type <code>Path</code> are used by all filesystem interfaces.
    Path objects are immutable.

    <p>
    The string representation of paths is a forward-slash-delimeted sequence of
    path components. The root directory is represented as a single forward
    slash.

    <p>
    The colon (<code>:</code>) and forward slash (<code>/</code>) characters are
    not permitted within path components. The forward slash is the delimeter,
    and the colon is reserved as a delimeter for application use.
 */
public class Path implements Iterable<String>, Comparable<Path>, Serializable
{
    public List<String> path;

    /** Creates a new path which represents the root directory. */
    public Path()
    {
        this.path = new ArrayList<String>();
    }

    /** Creates a new path by appending the given component to an existing path.

        @param path The existing path.
        @param component The new component.
        @throws IllegalArgumentException If <code>component</code> includes the
                                         separator, a colon, or
                                         <code>component</code> is the empty
                                         string.
    */
    public Path(Path path, String component)
    {
        // * illegal chars
        if (component == "" || component.contains(":") || component.contains("/"))
            throw new IllegalArgumentException();

        this.path = new ArrayList<String>();

        // * add the componentes to create a new path
        for (int i = 0; i < path.path.size(); i++)
            this.path.add(path.path.get(i));
        
        this.path.add(component);
    }

    /** Creates a new path from a path string.

        <p>
        The string is a sequence of components delimited with forward slashes.
        Empty components are dropped. The string must begin with a forward
        slash.

        @param path The path string.
        @throws IllegalArgumentException If the path string does not begin with
                                         a forward slash, or if the path
                                         contains a colon character.
     */
    public Path(String path)
    {
        this.path = new ArrayList<String>();
        String curr_comp = "";

        // * illegal chars
        if (path == "" || path.charAt(0) != '/' || path.contains(":"))
            throw new IllegalArgumentException();

        // * traverse the string, create the path, ignore empty dires
        for (int i = 0; i < path.length(); i++)
        {
            char curr = path.charAt(i);
            
            // * not an empty directory name
            if (curr == '/' && curr_comp.length() != 0)
            {
                this.path.add(curr_comp);
                curr_comp = "";
            }

            // * add to the component name
            else if (curr != '/')
            {
                curr_comp += curr;
                if (i == path.length() - 1)
                    this.path.add(curr_comp);
            }
        }
    }

    /** Returns an iterator over the components of the path.

        <p>
        The iterator cannot be used to modify the path object - the
        <code>remove</code> method is not supported.

        @return The iterator.
     */
    @Override
    public Iterator<String> iterator()
    {
        Iterator<String> it = new Iterator<String>() 
        {
            private int currentIndex = 0;

            @Override
            public boolean hasNext()
            {        
                // * stop at array bound
                return currentIndex < path.size();
            }

            @Override
            public String next() 
            {
                // * get the current, point to the next
                if (!hasNext()) 
                    throw new NoSuchElementException();

                return path.get(currentIndex++);
            }

            // * override the implemented remove method
            @Override
            public void remove() 
            {                     
                throw new UnsupportedOperationException("not implemented");
            }
        };

        return it;
    }

    /** Recursively lists the paths of all files in a directory tree on the local
        filesystem.

        @param directory The root directory of the directory tree.
        @return An array of relative paths, one for each file in the directory
                tree.
        @throws FileNotFoundException If the root directory does not exist.
        @throws IllegalArgumentException If <code>directory</code> exists but
                                         does not refer to a directory.
     */
    public static List<Path> list_h(File directory) throws FileNotFoundException
    {
        String path_string;
        List<Path> paths = new ArrayList<Path>();

        // * directory has to exist and be a directory
        if (!directory.exists())
            throw new FileNotFoundException();

        else if (!directory.isDirectory())
            throw new IllegalArgumentException();

        // * get URI for root to get relative path
        URI root_URI = directory.toURI();

        // * list all files and directories
        File[] files = directory.listFiles();

        for (int i = 0; i < files.length; i++)
        {
            // * if a nonempty directory
            if (files[i].isDirectory() && files[i].listFiles().length != 0)
            {
                // * call recursively to list all files
                List<Path> rec_files = list_h(files[i]);

                // * manipulate path to add the root
                for (int j = 0; j < rec_files.size(); j++) {
                    path_string = "/" + files[i].getName() + rec_files.get(j).toString();
                    paths.add(new Path(path_string));
                }
            }

            else
            {
                // * if a file or an empty directory, adjust path and add
                URI child_URI = files[i].toURI();
                URI relative_URI = root_URI.relativize(child_URI);
                path_string = "/" + relative_URI.getPath();
                paths.add(new Path(path_string));
            }
        }

        return paths;
    }

    /** Lists the paths of all files in a directory tree on the local
        filesystem.

        @param directory The root directory of the directory tree.
        @return An array of relative paths, one for each file in the directory
                tree.
        @throws FileNotFoundException If the root directory does not exist.
        @throws IllegalArgumentException If <code>directory</code> exists but
                                         does not refer to a directory.
     */
    public static Path[] list(File directory) throws FileNotFoundException
    {
        // * call helper method to get the array recursively
        List<Path> paths = list_h(directory);

        // * convert into a list
        Path[] result = new Path[paths.size()];
        return paths.toArray(result);   
    }

    /** Determines whether the path represents the root directory.

        @return <code>true</code> if the path does represent the root directory,
                and <code>false</code> if it does not.
     */
    public boolean isRoot()
    {
        // * root if empty
        return this.path.size() == 0;
    }

    /** Returns the path to the parent of this path.

        @throws IllegalArgumentException If the path represents the root
                                         directory, and therefore has no parent.
     */
    public Path parent()
    {
        // * root has no parent
        if (isRoot())
            throw new IllegalArgumentException();

        // * get the path to the parent by removing the last componentss
        String full_path = this.toString();
        Path parent_path = new Path(full_path);
        parent_path.path.remove(parent_path.path.size() - 1);
        return parent_path;
    }

    /** Returns the last component in the path.

        @throws IllegalArgumentException If the path represents the root
                                         directory, and therefore has no last
                                         component.
     */
    public String last()
    {
        // * root has no last component
        if (isRoot())
            throw new IllegalArgumentException();

        // * get last component as last elem in array
        return path.get(path.size() - 1);
    }

    /** Determines if the given path is a subpath of this path.

        <p>
        The other path is a subpath of this path if is a prefix of this path.
        Note that by this definition, each path is a subpath of itself.

        @param other The path to be tested.
        @return <code>true</code> If and only if the other path is a subpath of
                this path.
     */
    public boolean isSubpath(Path other)
    {
        // * can't be a subpath if smaller
        if (this.path.size() < other.path.size())
            return false;

        // * get sublist
        int other_size = other.path.size();
        List<String> subList = this.path.subList(0, other_size);

        // * check if subpath
        return subList.equals(other.path);
    }

    /** Converts the path to <code>File</code> object.

        @param root The resulting <code>File</code> object is created relative
                    to this directory.
        @return The <code>File</code> object.
     */
    public File toFile(File root)
    {
        // * construct a child File
        return new File(root.getPath() + this.toString());
    }
    
    /**
        @param other The other path.
        @return Zero if the two paths are equal, a negative number if this path
                precedes the other path, or a positive number if this path
                follows the other path.
    */
    @Override
    public int compareTo(Path other)
    {
        /** 
         * * if the two paths have the first componenet 
         * * in common then they are equal. (since they are locked at the same time)
         * * otherwise, use ldifference in length to compare
         */
        int thisSize = this.path.size();
        int otherSize = other.path.size();

        if (Math.min(thisSize, otherSize) >= 1 // * both are not empty
         && this.path.get(0).equals(other.path.get(0)))
            return 0;

        // * negative if other is longer, positive otherwise
        return this.path.size() - other.path.size();
    }

    /** Compares two paths for equality.

        <p>
        Two paths are equal if they share all the same components.

        @param other The other path.
        @return <code>true</code> if and only if the two paths are equal.
     */
    @Override
    public boolean equals(Object other)
    {
        // * check if Object is path
        if (other instanceof Path)
        {
            // * compare two arrays
            Path other_p = (Path) other;
            return this.path.equals(other_p.path);
        }
        else
            return false;
    }

    /** Returns the hash code of the path. */
    @Override
    public int hashCode()
    {
        return this.path.hashCode();
    }

    /** Converts the path to a string.

        <p>
        The string may later be used as an argument to the
        <code>Path(String)</code> constructor.

        @return The string representation of the path.
     */
    @Override
    public String toString()
    {
        String joined_path = "/" + String.join("/", this.path);
        return joined_path;
    }
} 
